Hooks.once('init', function() {
	const reloadSettings = foundry.utils.debounce(() => setheartbeat(null,null,'init'), 100);
	//console.log("Heartbeat found...");
	game.settings.register('heartbeat', 'enabledForThisUser', {
        name: 'Enabled for this user',
        hint: 'If heartbeat should be enabled for this user',
        scope: 'client',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'additionalActorTypes', {
        name: 'Additional Actor Types',
        hint: 'Comma-separated list of additional actor types to include (e.g., mecha, vehicle)',
        scope: 'world',
        config: true,
        default: 'mecha',
        type: String,
        onChange: () => { reloadSettings(); },
    });
	game.settings.register('heartbeat', 'enableTakeDamageffect', {
        name: 'Enable Damage Animation',
        hint: 'Enables the animation that is played when a character takes damage or regains hp',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'invertDamageOverlay', {
        name: 'Invert Damage Animation',
        hint: 'Some systems may calculate damage differently. Enable this to display the correct color for the damage animation.',
        scope: 'world',
        config: true,
        default: false,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'enableDamageOverlay', {
        name: 'Enable Damage Overlay',
        hint: 'Enables the overlay that stays until the character gets healed.',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'gmPreview', {
        name: 'GM Preview',
        hint: 'Lets you preview the effect by clicking on tokens',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'gmPreviewIgnoreNPC', {
        name: 'GM Preview Ignore NPCS',
        hint: 'Ignore NPCS when previewing the effect',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'heartbeatbutton', {
        name: 'Heartbeat Button Location ',
        hint: 'You can set where the small heart button will be displayed.',
        scope: 'world',
        config: true,
        type: String,
		default: 'topright',
		onChange: () => {reloadSettings();},
		choices: {
			"hidden": "hidden",
			"topright": "top right (standard)",
			"topleft": "top left",
			"macrobar" : "next to macro bar"
		},
    });
	game.settings.register('heartbeat', 'wounds', {
        name: 'Invert HP (More HP BAD)',
        hint: 'Use a different calculation where more hp == bad for systems like swade',
        scope: 'world',
        config: true,
        default: false,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });	
	game.settings.register('heartbeat', 'hpPath', {
        name: 'HP Data Path',
        hint: 'This is the path that points towards the HP value of an actor (standard DnD5e: system.attributes.hp.value)',
        scope: 'world',
        config: true,
        default: "system.attributes.hp.value",
        type: String,
		onChange: () => {reloadSettings();},
    });	
	game.settings.register('heartbeat', 'maxhpPath', {
        name: 'Max HP Data Path',
        hint: 'This is the path that points towards the HP value of an actor (standard DnD5e: system.attributes.hp.max)',
        scope: 'world',
        config: true,
        default: "system.attributes.hp.max",
        type: String,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'start_heartbeat_offset', {
        name: 'Start Heartbeat HP%',
        hint: 'Defines at which percentage the overlay should start to appear',
        scope: 'world',
        config: true,
        default: '50',
		type: Number,
		range: {
			min: 1,
			max: 99,
			step: 1
		},
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'heartbeat_offset', {
        name: 'Heartbeat FX HP%',
        hint: 'Defines at which percentage the animation and sound should start',
        scope: 'world',
        config: true,
        default: '10',
		type: Number,
		range: {
			min: 1,
			max: 99,
			step: 1
		},
		onChange: () => {reloadSettings();},
    });		
	game.settings.register('heartbeat', 'effect_multiplier', {
        name: 'Effect Multiplier',
        hint: 'Defines how strong the overlay is',
        scope: 'world',
        config: true,
        default: '0.5',
		type: Number,
		range: {
			min: 0.01,
			max: 1,
			step: 0.01
		},
		onChange: () => {reloadSettings();},
    });	
	game.settings.register('heartbeat', 'sfx_heartbeat', {
        name: 'Heartbeat Sound',
        hint: 'path to the sound',
        scope: 'world',
        config: true,
        default: 'modules/heartbeat/sfx/heartbeat_sfx.mp3',
        type: String,
		filePicker: 'audio',
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'sfx_heartbeat_vol', {
        name: 'Heartbeat Sound Volume',
        hint: 'volume of the sound',
        scope: 'world',
        config: true,
        default: '0.1',
		type: Number,
		range: {
			min: 0,
			max: 1,
			step: 0.01
		},
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'canvasBlur', {
        name: 'enable CanvasBlur',
        hint: 'The canvas will be blurry at a lower percentage of health;',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'canvasBrightness', {
        name: 'enable CanvasBrightness',
        hint: 'The canvas will get darker at a lower percentage of health;',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'massiveDamageSound', {
        name: 'enable Massive Damage Sound',
        hint: 'a custom sound that will be played when players take over 50% damage in one attack',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'tokenDeath', {
        name: 'Token Death (Black Screen)',
        hint: 'The Screen will be black and white once a character reaches 0 hp',
        scope: 'world',
        config: true,
        default: true,
        type: Boolean,
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'sfx_massivedamage', {
        name: 'Massive Damage Sound',
        hint: 'path to the sound',
        scope: 'world',
        config: true,
        default: 'modules/heartbeat/sfx/ear_ringing_sfx.mp3',
        type: String,
		filePicker: 'audio',
		onChange: () => {reloadSettings();},
    });
	game.settings.register('heartbeat', 'bloodOverlay_path', {
        name: 'Bloody Overlay Path',
        hint: 'Spath to the blood overlay',
        scope: 'world',
        config: true,
        default: "modules/heartbeat/images/bloody.webp",
		type: String,
		filePicker: 'image',
    });
	game.settings.register('heartbeat', 'blood_blur', {
        name: 'Blood Blur',
        hint: 'How blurry the blood will be on the screen (a setting between 0-30 is recommended)',
        scope: 'world',
        config: true,
        default: '5',
		type: Number,
		range: {
			min: 0,
			max: 90,
			step: 1
		},
		onChange: () => {reloadSettings();},
	});
	game.settings.register('heartbeat', 'enableSplatter', {
		name: 'Enable Massive Damage Splatter',
		hint: 'Enables persistent splatter effect (images) when massive damage is taken',
		scope: 'world',
		config: true,
		default: true,
		type: Boolean,
		onChange: () => {reloadSettings();},
	});
	game.settings.register('heartbeat', 'disableSplatterForGM', {
		name: 'Disable Splatter for GM',
		hint: 'If enabled, GMs will not see the splatter effects. Useful to not have dozens of splatters when juggling monsters in combat.',
		scope: 'world',
		config: true,
		default: true,
		type: Boolean,
		onChange: () => { reloadSettings(); },
	});
	game.settings.register('heartbeat', 'splatterThreshold', {
		name: 'Splatter Threshold (%)',
		hint: 'The minimum percentage of maximum HP lost in a single hit to trigger the splatter effect.',
		scope: 'world',
		config: true,
		default: 20,
		type: Number,
		range: {
			min: 1,
			max: 100,
			step: 1
		},
		onChange: () => { reloadSettings(); },
	});
	game.settings.register('heartbeat', 'splatterDuration', {
		name: 'Splatter Duration',
		hint: 'Duration (in seconds) for which splatter remains visible before fading out',
		scope: 'world',
		config: true,
		default: 30, // Default to 10 seconds
		type: Number,
		onChange: () => {reloadSettings();},
	});
	game.settings.register('heartbeat', 'enableScreenShake', {
		name: 'Enable Screen Shake',
		hint: 'Shakes the screen briefly when a character takes damage.',
		scope: 'world',
		config: true,
		default: true,
		type: Boolean,
		onChange: () => { reloadSettings(); },
	});
	game.settings.register('heartbeat', 'screenShakeStrength', {
		name: 'Screen Shake Strength',
		hint: 'Determines the base intensity of screen shake when taking damage.',
		scope: 'world',
		config: true,
		default: 5,
		type: Number,
		range: {
			min: 0,
			max: 10,
			step: 0.1
		},
		onChange: () => { reloadSettings(); },
	});
	
	game.settings.register('heartbeat', 'scaleScreenShakeWithHP', {
		name: 'Scale Screen Shake with HP Loss',
		hint: 'If enabled, the shake intensity scales based on the percentage of HP lost.',
		scope: 'world',
		config: true,
		default: true,
		type: Boolean,
		onChange: () => { reloadSettings(); },
	});
	game.settings.register('heartbeat', 'hasSeenRecommendation', {
		scope: 'world',
		name: 'Has seen recommended Settings',
		hint: 'If enabled, you will no longer see recommended settings. Enabled automatically.',
		config: true,
		default: false,
		type: Boolean
	});
	console.log("Heartbeat enabled!");
});

Hooks.once('ready', function() {
	if(game.settings.get('heartbeat', 'enableTakeDamageffect'))
		$('body').append('<img class="hearbeat" id="heartbeat" src="'+ game.settings.get('heartbeat', 'bloodOverlay_path') +'" style="pointer-events:none; position: absolute;width: inherit;height: inherit;opacity: 0.0;">')
	if(game.settings.get('heartbeat', 'enableDamageOverlay'))
		$('body').append('<img class="hearbeatDMGOverlay" id="hearbeatDMGOverlay" style="pointer-events:none; position: absolute;width: inherit;height: inherit;opacity: 0.0;">')
	
	if(canvas.tokens.controlled[0] != undefined){
		setheartbeat(null,canvas.tokens.controlled[0], 'ready');
	}

	//CREATE HEARTBEAT BUTTON
	// Create the button element
	let buttonLocation = game.settings.get('heartbeat', 'heartbeatbutton');
	if(buttonLocation == 'hidden') return;

	const heartbeatButton = document.createElement('button');
	heartbeatButton.setAttribute('type', 'button');
	heartbeatButton.setAttribute('id', 'heartbeat-button');
	heartbeatButton.textContent = ''; // Set the button's text content
	heartbeatButton.title = "";
	//"hidden": "hidden",
	//"topright": "top right (standard)",
	//"topleft": "top left",
	//"macrobar" : "next to macro bar",
	heartbeatButton.onclick = function() {
		toggleHeartBeatForCurrentUser(); // Call your toggleHeartBeatForCurrentUser function
	};
	if(buttonLocation == 'topright'){
		heartbeatButton.style = "left: calc(0px - 1.4rem);top: calc(35px - 1.4rem);";
		$("#sidebar")[0].append(heartbeatButton);
	}
	if(buttonLocation == 'topleft'){
		heartbeatButton.style = "left: calc(128px - 1.4rem);top: calc(39px - 1.4rem);";
		$("#ui-left")[0].append(heartbeatButton);
	}
	if(buttonLocation == 'macrobar'){
		heartbeatButton.style = "left: calc(600px - 1.4rem);bottom: calc(47px - 1.4rem);";
		$("#ui-bottom")[0].append(heartbeatButton);
	}

	// Change style based on setting
	if(game.settings.get('heartbeat', 'enabledForThisUser'))
		changeHeartBeatButtton('on');
	else{
		changeHeartBeatButtton('off');
}

	
});
function toggleHeartBeatForCurrentUser(){
	let newval = !game.settings.get('heartbeat', 'enabledForThisUser');
	game.settings.set('heartbeat', 'enabledForThisUser', newval);
	if(newval){
		changeHeartBeatButtton('on');
		//TODO: Try enabling heartbeat
	}
	else{
		disableHeartBeat();
		changeHeartBeatButtton('off');
	}
}
function changeHeartBeatButtton(enableDisable) {
	let button = $('#heartbeat-button')[0];
	if(button == undefined)return;
	if (enableDisable === 'on') {
	  button.textContent = '❤️'; // Set the button's text content
	  button.title = 'Heartbeat Active - Click to disable';
	}
	if (enableDisable === 'beat') {
	  button.textContent = '💓'; // Set the button's text content
	  button.title = 'Heartbeat Beating';
	  //button.classList.add('animatedHeartBeatButton');
	  //button.classList.remove('animatedHeartBeatButton');
	}
	if (enableDisable === 'off') {
	  button.textContent = '🖤'; // Set the button's text content
	  button.title = 'Heartbeat Inactive - Click to enable';
	}
	if (enableDisable === 'special') {
		button.textContent = '💛'; // Set the button's text content
		button.title = 'Heartbeat Inactive - Disabled for this actor type';
	  }
  }
Hooks.on("controlToken", (t, e) => {
	if(game.user.isGM && game.settings.get('heartbeat', 'gmPreview'))
		if(t.actor.type != 'character' && game.settings.get('heartbeat', 'gmPreviewIgnoreNPC')){
			disableHeartBeat();
			return;
		}
	else{
		setheartbeat(null, t, 'controlToken');
	}

});
Hooks.on("sightRefresh", (t, e) => {
	if(game.user.isGM && game.settings.get('heartbeat', 'gmPreview')){
		let tokens = canvas.tokens.controlled;
		if(tokens.length == 0) disableHeartBeat();
	}
});
function getNewHPValue(actor, updates, hpPath) {
    // Create a copy of the actor's data
    let actorData = duplicate(actor);

    // Merge the updates into the actor's data
    mergeObject(actorData, updates, { inplace: true });

    // Retrieve the new HP value
    let newHP = deep_value(actorData, hpPath);

    return newHP;
}
Hooks.on('preUpdateActor', (actor, updates, options, userId) => {
    if (!game.settings.get('heartbeat', 'enabledForThisUser')) return;

    const controlledTokens = canvas.tokens.controlled.map(t => t.actor?.id);
    if (canvas.tokens.controlled.length > 1) {// If more than one actor is selected
        return;
    }
    if (canvas.tokens.controlled[0].actor.id != actor.id) {// If the player controls a different token return
        return;
    }

    // Get the HP path from settings
    let hpPath = game.settings.get('heartbeat', 'hpPath');

    // Retrieve the old HP from the actor's current data
    let oldHP = deep_value(actor, hpPath);

    // Store old HP in options
    options.oldHP = oldHP;
});
Hooks.on('updateActor', (actor, updates, options, userId) => {
    if (!game.settings.get('heartbeat', 'enabledForThisUser')) return;
    if (canvas.tokens.controlled.length > 1) {// If more than one actor is selected
        return;
    }
    if (canvas.tokens.controlled[0].actor.id != actor.id) {// If the player controls a different token return
        return;
    }
    if (options.oldHP == null) return;
    let hpPath = game.settings.get('heartbeat', 'hpPath');

    // Retrieve the new HP from the actor's updated data
    let newHP = deep_value(actor, hpPath);

    if (options.oldHP == null || newHP == null) return;

    let damageTaken = newHP - options.oldHP;

    let tokens = canvas.tokens.controlled;
    if (game.user.isGM && game.settings.get('heartbeat', 'gmPreview')) {
        if (tokens.length > 1 || tokens.length == 0) return;
        else if (!isActorTypeAllowed(actor)) {
            disableHeartBeat();
            return;
        }
        setheartbeat(damageTaken, tokens[0], 'updateActor');
    } else if (tokens.length == 1 && !canvas.tokens.controlled[0].actor.actorLink) {
        console.log("Heartbeat | Your selected token has been updated: " + actor.name);
        setheartbeat(damageTaken, tokens[0], 'updateActor');
    } else if (game.user.character != undefined) {
        if (game.user.character.id == actor.id) {
            console.log("Heartbeat | Your character has been updated: " + actor.name);
            setheartbeat(damageTaken, null, 'updateActor');
        }
    }
});
function isActorTypeAllowed(actor) {
    // Retrieve additional actor types from settings
    let additionalTypesSetting = game.settings.get('heartbeat', 'additionalActorTypes');
    let additionalActorTypes = additionalTypesSetting.split(',')
        .map(type => type.trim().toLowerCase())
        .filter(type => type);

    // Combine default types with additional types
    let allowedActorTypes = ['character', 'npc', ...additionalActorTypes];

    // Check if the actor's type is in the allowed list
    return allowedActorTypes.includes(actor.type.toLowerCase());
}

function disableHeartBeat() {
    document.getElementById("heartbeat").style.opacity = 0;
    $("#board")[0].style.filter = '';
    
    if (!game.settings.get('heartbeat', 'enabledForThisUser')) {
        changeHeartBeatButtton('off');
    }

    const soundsrc = game.settings.get('heartbeat', 'sfx_heartbeat');
    game.audio.playing.forEach(function(sound) {
        if (sound.src.endsWith(soundsrc)) {
            sound.stop();
        }
    });
}

async function damage(percent, dhp = null, maxHp) {
    if (!game.settings.get('heartbeat', 'enableDamageOverlay')) return;
    let damageAmount = dhp || 0;

    // Invert damage overlay if setting is enabled
    if (game.settings.get('heartbeat', 'invertDamageOverlay'))
        dhp = -dhp;


	if (dhp < 0) {
		let baseStrength = game.settings.get('heartbeat', 'screenShakeStrength');
		let scaleWithHP = game.settings.get('heartbeat', 'scaleScreenShakeWithHP');
	
		let damagePercent = Math.abs(dhp) / maxHp;
		let shakeIntensity = scaleWithHP
			? Math.max(2, baseStrength * damagePercent)
			: baseStrength;
	
		let shakeDuration = Math.min(400, Math.max(100, damagePercent * 400));
	
		screenShake(shakeIntensity, shakeDuration);
	}

    // Set the damage overlay color based on whether HP increased or decreased
    if (dhp > 0) {
        $("#hearbeatDMGOverlay")[0].style.background = "radial-gradient(circle, rgba(255, 255, 255, 0%) 27%, rgb(0, 145, 25) 100%)";
    } else {
        $("#hearbeatDMGOverlay")[0].style.background = "radial-gradient(circle, rgba(255, 255, 255, 0%) 27%, rgb(145, 0, 0) 100%)";
    }

    // Calculate duration for the animation
    let duration = 1 + damageAmount / 1000 + (1 - percent);
    if (game.settings.get('heartbeat', 'wounds'))
        duration = 1;

    // Start the damage overlay animation
    $("#hearbeatDMGOverlay")[0].style.animation = "HeartBeatFadeOut " + duration + "s";
    await delay(duration * 1000);
    $("#hearbeatDMGOverlay")[0].style.animation = "";
	
    if (maxHp > 0 && dhp != null && dhp <= 0) {
        let damagePercentage = (Math.abs(dhp) / maxHp) * 100;
        let splatterThreshold = game.settings.get('heartbeat', 'splatterThreshold');
        if (damagePercentage >= splatterThreshold) {
            spawnSplatter();
        }
    }
}

function deep_value(obj, path) {
    return path.split('.').reduce((accumulator, key) => {
        if (accumulator && accumulator[key] !== undefined) {
            return accumulator[key];
        } else {
            return undefined;
        }
    }, obj);
}

function HB_play(src, volume, loop = false) {
    const helper = foundry?.audio?.AudioHelper || AudioHelper;
    if (!helper?.play || !src) return;
    
    const soundPath = src.startsWith('/') ? src : `/${src}`;
    helper.play({ 
        src: soundPath, 
        volume: parseFloat(volume), 
        loop: loop, 
        autoplay: true 
    }, false);
}

function setheartbeat(damageTaken = null, token = null, source = null){
	if(!game.settings.get('heartbeat', 'enabledForThisUser')) return;
	let character;

	if(token != null) character = token.actor;
	if(game.user.character != null && !game.user.isGM) character = game.user.character;
	if(game.user.character == null && token == null){
		if(canvas.tokens.controlled.length == 1) character = canvas.tokens.controlled[0].actor;
		else return;
	};

	let additionalTypesSetting = game.settings.get('heartbeat', 'additionalActorTypes');
	let additionalActorTypes = additionalTypesSetting.split(',').map(type => type.trim().toLowerCase()).filter(type => type);
	let allowedActorTypes = ['character', 'npc', ...additionalActorTypes];
	
    if (!allowedActorTypes.includes(character.type.toLowerCase())) {
		disableHeartBeat();
		changeHeartBeatButtton('special');
		return;
	}

	let path = game.settings.get('heartbeat', 'hpPath');
	let maxhpPath = game.settings.get('heartbeat', 'maxhpPath');
	let hp = deep_value(character, path);
	let maxHp = deep_value(character, maxhpPath);
	let woundSystem = game.settings.get('heartbeat', 'wounds');
	let effect_multiplier = game.settings.get('heartbeat', 'effect_multiplier');

	if(maxHp == 0){
		disableHeartBeat();
		changeHeartBeatButtton('special');
		return;
	}

	if(hp == null || maxHp == null){
        ui.notifications.warn("Heartbeat | HP Data Path incorrect.");
        return;
	}

	changeHeartBeatButtton('beat');
	let percent = hp / maxHp;

	if(damageTaken) damage(percent, damageTaken, maxHp);
	
	let blur = 'blur(' + game.settings.get("heartbeat", "blood_blur") + 'px)';
	document.getElementById("heartbeat").style.filter = blur;

    let soundsrc = game.settings.get('heartbeat', 'sfx_heartbeat');

	if(woundSystem){
		if(percent >= game.settings.get('heartbeat', 'start_heartbeat_offset')/100 && percent != 0){
			document.getElementById("heartbeat").style.opacity = percent;
			if(percent >= game.settings.get('heartbeat', 'heartbeat_offset')/100 && percent < 1){
				document.getElementById("heartbeat").classList.add("animated")
			}
			else{
				document.getElementById("heartbeat").classList.remove("animated")
			}
			if(percent != 1 && percent != 0){
				let blurvalue = percent*(2*effect_multiplier);
				let brightnessvalue = 1-percent*effect_multiplier;
				let style = '';
				if(game.settings.get('heartbeat', 'canvasBlur')) style += 'blur('+blurvalue+'px )';
				if(game.settings.get('heartbeat', 'canvasBrightness')) style += 'brightness('+brightnessvalue+')';
				$("#board")[0].style.filter = style;
			}
			else $("#board")[0].style.filter = '';
		}
		else{
			$("#board")[0].style.filter = '';
			document.getElementById("heartbeat").style.opacity = 0;
		}

		let isLowHealthWounds = percent >= game.settings.get('heartbeat', 'heartbeat_offset')/100 && percent < 1;
		if(isLowHealthWounds){
			let alreadyplaying = false;
			game.audio.playing.forEach(s => { if(s.src.endsWith(soundsrc)) alreadyplaying = true; });
			if(!alreadyplaying) HB_play(soundsrc, game.settings.get('heartbeat', 'sfx_heartbeat_vol'), true);
		}
		else{
			game.audio.playing.forEach(s => { if(s.src.endsWith(soundsrc)) s.stop(); });
		}
		
		if(percent == 1 && game.settings.get('heartbeat', 'tokenDeath')){
			$("#board")[0].style.filter = 'grayscale(1) brightness(0.2)';
			$("#heartbeat")[0].style.filter = 'blur(0) grayscale(1) brightness(0.1)';
		}
		return;
	}

	if(percent <= game.settings.get('heartbeat', 'heartbeat_offset')/100 && percent != 0){
		document.getElementById("heartbeat").classList.add("animated")
	}
	else{
		document.getElementById("heartbeat").classList.remove("animated")
	}

	if(percent <= game.settings.get('heartbeat', 'start_heartbeat_offset')/100 && percent != 0){
		document.getElementById("heartbeat").style.opacity = game.settings.get('heartbeat', 'effect_multiplier') - percent;
		let blurvalue = (1-percent*2);
		let brightnessvalue = 1 - (0.8-percent);
		let style = '';
		if(game.settings.get('heartbeat', 'canvasBlur')) style += 'blur('+blurvalue+'px )';
		if(game.settings.get('heartbeat', 'canvasBrightness')) style += 'brightness('+brightnessvalue+')';
		$("#board")[0].style.filter = style;
	}
	else{
		$("#board")[0].style.filter = '';
		document.getElementById("heartbeat").style.opacity = 0;
	}

	let isLowHealthStd = percent <= game.settings.get('heartbeat', 'heartbeat_offset')/100 && percent != 0;
	if(isLowHealthStd){
		let alreadyplaying = false;
		game.audio.playing.forEach(s => { if(s.src.endsWith(soundsrc)) alreadyplaying = true; });
		if(!alreadyplaying) HB_play(soundsrc, game.settings.get('heartbeat', 'sfx_heartbeat_vol'), true);
	}
	else{
		game.audio.playing.forEach(s => { if(s.src.endsWith(soundsrc)) s.stop(); });
	}

	if(percent == 0 && game.settings.get('heartbeat', 'tokenDeath')){
		$("#board")[0].style.filter = 'grayscale(1) brightness(0.2)';
		$("#heartbeat")[0].style.filter = 'blur(0) grayscale(1) brightness(0.1)';
		document.getElementById("heartbeat").style.opacity = 1;
		if(damageTaken != null) {
			spawnSplatter();
			spawnSplatter();
			spawnSplatter();
		}
	}
    
    if(damageTaken){
        const threshold = maxHp / 2;
        const isMassive = game.settings.get('heartbeat', 'invertDamageOverlay') ? (damageTaken >= threshold) : (-damageTaken >= threshold);
        if(isMassive && percent < 0.50 && game.settings.get('heartbeat', 'massiveDamageSound')){
            HB_play(game.settings.get('heartbeat', 'sfx_massivedamage'), 0.05, false);
            spawnSplatter();
        }
    }
}
let splatterImages = [];
const delay = ms => new Promise(res => setTimeout(res, ms));
let bloodImages = [];
for(let i = 1; i <= 11; i++) {
    let num = i.toString().padStart(2, '0'); // pad with leading zero
    bloodImages.push(`modules/heartbeat/images/BloodStains/Blood_${num}.png`);
}
function screenShake(intensity = 5, duration = 500) {
    if (!game.settings.get('heartbeat', 'enableScreenShake')) return;

    let body = document.body;
    let start = Date.now();
    
    function shake() {
        let elapsed = Date.now() - start;
        if (elapsed >= duration) {
            body.style.transform = '';
            return;
        }
        let x = (Math.random() * 2 - 1) * intensity;
        let y = (Math.random() * 2 - 1) * intensity;
        body.style.transform = `translate(${x}px, ${y}px)`;
        requestAnimationFrame(shake);
    }

    shake();
}
function spawnSplatter() {
	if (game.user.isGM && game.settings.get('heartbeat', 'disableSplatterForGM')) return;
	if(game.settings.get('heartbeat', 'enableSplatter') == false) return;

    let randomIndex = Math.floor(Math.random() * bloodImages.length);
    let imgSrc = bloodImages[randomIndex];
    let splatterImg = document.createElement('img');
    splatterImg.src = imgSrc;
    splatterImg.classList.add('HeartbeatSplatterImage');
    splatterImg.style.pointerEvents = 'none';
    splatterImg.style.position = 'fixed';

    let boardElement = $("#board")[0];
    let boardRect = boardElement.getBoundingClientRect();

    // Remove boardRect.left and boardRect.top from the calculation
    let posX = boardRect.x + Math.random();
    let posY = boardRect.y + Math.random();

    splatterImg.style.left = posX + 'px';
    splatterImg.style.top = posY + 'px';

    let rotation = Math.random() * 360;
    let scale = 0.5 + Math.random() * (3.0 - 0.5);
    splatterImg.style.transform = `rotate(${rotation}deg) scale(${scale})`;

    splatterImg.style.opacity = '1';
    splatterImg.style.zIndex = 10;

    document.body.appendChild(splatterImg);
    splatterImages.push(splatterImg);

    let duration = Number(game.settings.get('heartbeat', 'splatterDuration')) * 1000;

    splatterImg.style.transition = `opacity ${duration / 1000}s linear`;

    setTimeout(() => {
        splatterImg.style.opacity = '0';
    }, 100);

    setTimeout(() => {
        removeSplatterImage(splatterImg);
    }, duration);
}

function removeSplatterImage(splatterImg) {
    if (splatterImg) {
        splatterImg.remove();
        splatterImages = splatterImages.filter(img => img !== splatterImg);
    }
}
Hooks.once('ready', async function() {
    if (!game.user.isGM) return;

    const systemPresets = await loadSystemPresets();
    const currentSystem = game.system.id;
    const defaultHpPath = "system.attributes.hp.value";
    const defaultMaxHpPath = "system.attributes.hp.max";
    const defaultActorTypes = "character,npc";

    const hasSeenRecommendation = game.settings.get('heartbeat', 'hasSeenRecommendation');
    if (hasSeenRecommendation || currentSystem === "dnd5e") return;

    const currentHpPath = game.settings.get('heartbeat', 'hpPath');
    const currentMaxHpPath = game.settings.get('heartbeat', 'maxhpPath');
    const currentActorTypes = game.settings.get('heartbeat', 'additionalActorTypes');

    let preset = systemPresets[currentSystem] || null;
    let requiresSetup = !preset;

    let availableActorTypes = Object.keys(game.model.Actor || {});
    let translatedActors = game.i18n.translations.ACTOR || {};

    let actorTypeCheckboxes = availableActorTypes.map(type => {
        let localizedLabel = translatedActors[`Type${type.charAt(0).toUpperCase() + type.slice(1)}`] || type.charAt(0).toUpperCase() + type.slice(1);
        let isChecked = preset ? preset.allowedActorTypes.includes(type) : false;
        return `<label>
                    <input type="checkbox" class="actor-type-checkbox" value="${type}" ${isChecked ? "checked" : ""}>
                    ${localizedLabel}
                </label><br>`;
    }).join("");

    let messageContent = preset
        ? `<p>The detected system (<strong>${preset.name}</strong>) has a recommended configuration.</p>
           <p>Would you like to apply it?</p>
           <hr>
           <p><strong>Current HP Path:</strong></p>
           <p>${currentHpPath} → <strong>${preset.hpPath}</strong></p>
           <p><strong>Current Max HP Path:</strong></p>
           <p>${currentMaxHpPath} → <strong>${preset.maxHpPath}</strong></p>`
        : `<p>Your system (<strong>${currentSystem}</strong>) does not have a recommended preset.</p>
           <p class="HBWarnText">You may need to manually configure the HP and Max HP paths in the module settings.</p>
           <p>Please select which type of actors should be affected by Heartbeat below.</p>`;

    new Dialog({
        title: "Heartbeat Configuration",
        content: `
            <h1 class="h1HeartBeat">Heartbeat</h1>
            ${messageContent}
            <p><strong>Select Actor Types to Enable:</strong></p>
            <form id="actorTypeSelection">
                ${actorTypeCheckboxes}
            </form>`,
        buttons: {
            yes: {
                label: "Apply Settings",
                callback: async (html) => {
                    let selectedTypes = Array.from(html.find(".actor-type-checkbox:checked")).map(cb => cb.value);
                    if (preset) {
                        await game.settings.set('heartbeat', 'hpPath', preset.hpPath);
                        await game.settings.set('heartbeat', 'maxhpPath', preset.maxHpPath);
                    }
                    await game.settings.set('heartbeat', 'additionalActorTypes', selectedTypes.join(', '));
                    await game.settings.set('heartbeat', 'hasSeenRecommendation', true);
                    ui.notifications.info(`Applied settings for ${preset ? preset.name : currentSystem}.`);
                }
            },
            no: {
                label: "Don't ask again",
                callback: async () => {
                    await game.settings.set('heartbeat', 'hasSeenRecommendation', true);
                    ui.notifications.warn(`Default settings remain. Configure manually in module settings if needed.`);
                }
            }
        },
        default: "yes"
    }).render(true);
});


async function loadSystemPresets() {
    const githubURL = "https://raw.githubusercontent.com/Handyfon/heartbeat/master/systemSettings.json";
    
    try {
        const response = await fetch(githubURL, { cache: "no-cache" });
        if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);

        const json = await response.json();
        console.log("Heartbeat | Loaded system presets from GitHub.");
        return json;
    } catch (error) {
        console.warn("Heartbeat | Failed to load system presets from GitHub. Defaulting to unsupported system behavior.", error);
        return {}; // No fallback, just return empty object
    }
}
